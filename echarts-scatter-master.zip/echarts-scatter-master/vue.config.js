module.exports = {
  publicPath: '/echarts-scatter/',
  outputDir: 'docs'
}
