<template>
  <fm-making-form ref="makingForm" upload preview generate-code generate-json clearable>
    <template slot="action">
    </template>
  </fm-making-form>
</template>

<script>
export default {
  mounted () {
  }
}
</script>
