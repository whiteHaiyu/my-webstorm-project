export default {
  input: 'blur,change',
  select: 'change',
  radio: 'change',
  checkbox: 'change',
  cascader: 'input',
  uploads: 'handleUploadsValue',
  textarea: 'blur,change',
}
